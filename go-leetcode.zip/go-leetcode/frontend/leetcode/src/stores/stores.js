import { writable } from "svelte/store"

export const timeToExpireStore = writable("")
export const accessTokenStore = writable("")