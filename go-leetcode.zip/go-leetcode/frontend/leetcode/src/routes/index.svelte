<script>
    console.log("reached index page")
</script>

<svelte:head>
    <title>go-leetcode</title>
</svelte:head>

<h1 class="text-4xl text-center my-8">Welcome to go-leetcode!</h1>
<p>Here you can practice your programming skills with our curated questions, just like the OG Leetcode app.</p>