// template file
// insert Solution class here
class Solution {
    public int[] twoSum(int[] nums, int target) {
        int[nums.length] output;
        for (int i = 0; i < nums.length; i++) {
            output[i] = nums[i] + target;
        }
        return output;
    }
}

public class Template {
    public static void main(String[] args) {
        Solution sol = new Solution();
        boolean isOk = true;
        for (int i = 0; i < )
    }
}