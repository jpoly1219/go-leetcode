#include <iostream>

using namespace std;

int main() {
    cout << "running test.cpp" << endl;
    return 0;
}